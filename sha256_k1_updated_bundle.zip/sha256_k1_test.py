#!/usr/bin/env python3
"""
Low-CPU SHA-256 differential pre-screen.

This script implements:
1) the SHA-256 XOR-linearized message schedule over GF(2),
2) homogeneous Gaussian elimination over 512 message-bit variables,
3) nullspace/activity tests for published support patterns and K1/K2,
4) exact one-bit differential counts for Ch and Maj,
5) a small hill-climber for raw message/tail Hamming weight.

Important: this is a necessary-condition pre-screen, not a collision proof.
It does not model modular-addition carries or a complete state trail.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass, asdict
from typing import Callable, Iterable

MASK32 = (1 << 32) - 1
N_VARS = 16 * 32


def rotr32(x: int, n: int) -> int:
    return ((x >> n) | ((x << (32 - n)) & MASK32)) & MASK32


def shr32(x: int, n: int) -> int:
    return x >> n


def s0_num(x: int) -> int:
    return rotr32(x, 7) ^ rotr32(x, 18) ^ shr32(x, 3)


def s1_num(x: int) -> int:
    return rotr32(x, 17) ^ rotr32(x, 19) ^ shr32(x, 10)


def big_s0_num(x: int) -> int:
    return rotr32(x, 2) ^ rotr32(x, 13) ^ rotr32(x, 22)


def big_s1_num(x: int) -> int:
    return rotr32(x, 6) ^ rotr32(x, 11) ^ rotr32(x, 25)


def symbolic_rotr(word: list[int], n: int) -> list[int]:
    # Output bit j of ROTR_n(x) is input bit (j+n) mod 32.
    return [word[(j + n) % 32] for j in range(32)]


def symbolic_shr(word: list[int], n: int) -> list[int]:
    # Output bit j of SHR_n(x) is input bit j+n, or zero.
    return [word[j + n] if j + n < 32 else 0 for j in range(32)]


def word_xor(*words: list[int]) -> list[int]:
    return [a ^ b ^ c ^ d for a, b, c, d in zip(*words)]


def symbolic_s0(word: list[int]) -> list[int]:
    return word_xor(symbolic_rotr(word, 7), symbolic_rotr(word, 18), symbolic_shr(word, 3), [0] * 32)


def symbolic_s1(word: list[int]) -> list[int]:
    return word_xor(symbolic_rotr(word, 17), symbolic_rotr(word, 19), symbolic_shr(word, 10), [0] * 32)


def build_symbolic_schedule(n_words: int) -> list[list[int]]:
    if n_words < 16:
        raise ValueError("n_words must be at least 16")
    words: list[list[int]] = []
    for wi in range(16):
        words.append([1 << (32 * wi + bit) for bit in range(32)])
    for i in range(16, n_words):
        words.append(word_xor(symbolic_s1(words[i - 2]), words[i - 7], symbolic_s0(words[i - 15]), words[i - 16]))
    return words


def rref(rows: Iterable[int]) -> tuple[list[int], list[int]]:
    """Return RREF rows and pivot columns for homogeneous GF(2) equations."""
    work = [r for r in rows if r]
    pivot_rows: list[int] = []
    pivot_cols: list[int] = []
    col = 0
    while col < N_VARS and work:
        idx = next((i for i, row in enumerate(work) if (row >> col) & 1), None)
        if idx is None:
            col += 1
            continue
        pivot = work.pop(idx)
        # Clear this column in all remaining and already selected rows.
        work = [row ^ pivot if ((row >> col) & 1) else row for row in work]
        pivot_rows = [row ^ pivot if ((row >> col) & 1) else row for row in pivot_rows]
        pivot_rows.append(pivot)
        pivot_cols.append(col)
        col += 1
    # Sort by pivot column for deterministic nullspace reconstruction.
    pairs = sorted(zip(pivot_cols, pivot_rows))
    return [r for _, r in pairs], [p for p, _ in pairs]


def nullspace_basis(rref_rows: list[int], pivots: list[int]) -> list[int]:
    pivot_set = set(pivots)
    free_cols = [c for c in range(N_VARS) if c not in pivot_set]
    basis: list[int] = []
    for free in free_cols:
        vector = 1 << free
        # In RREF: x_p + sum(row_free*x_free)=0.
        for pivot, row in zip(pivots, rref_rows):
            if (row >> free) & 1:
                vector |= 1 << pivot
        basis.append(vector)
    return basis


def vector_to_initial_words(vector: int) -> list[int]:
    return [(vector >> (32 * i)) & MASK32 for i in range(16)]


def expand_numeric(initial: list[int], n_words: int) -> list[int]:
    words = list(initial)
    for i in range(16, n_words):
        words.append(s1_num(words[i - 2]) ^ words[i - 7] ^ s0_num(words[i - 15]) ^ words[i - 16])
    return [w & MASK32 for w in words]


def constraints_for_support(symbolic: list[list[int]], support: set[int], end: int) -> list[int]:
    rows: list[int] = []
    for i in range(end + 1):
        if i not in support:
            rows.extend(symbolic[i])
    return rows


def all_active(words: list[int], support: set[int]) -> bool:
    return all(words[i] != 0 for i in support)


def random_solution_with_all_active(basis: list[int], support: set[int], end: int, seed: int, attempts: int = 20000) -> int | None:
    if not basis:
        return None
    rng = random.Random(seed)
    for _ in range(attempts):
        v = 0
        # Random nullspace combination.
        coeffs = rng.getrandbits(len(basis))
        for i, b in enumerate(basis):
            if (coeffs >> i) & 1:
                v ^= b
        if v and all_active(expand_numeric(vector_to_initial_words(v), end + 1), support):
            return v
    return None


def raw_objective(vector: int, support: set[int], end: int, window_end: int) -> tuple[int, int, int]:
    words = expand_numeric(vector_to_initial_words(vector), window_end + 1)
    support_hw = sum(words[i].bit_count() for i in support)
    tail_hw = sum(words[i].bit_count() for i in range(end + 1, window_end + 1))
    return support_hw + tail_hw, support_hw, tail_hw


def hill_climb(basis: list[int], support: set[int], end: int, window_end: int, seed: int, restarts: int = 20) -> tuple[int | None, tuple[int, int, int] | None]:
    if not basis:
        return None, None
    rng = random.Random(seed)
    best_v = None
    best_score = None
    for _ in range(restarts):
        v = 0
        for b in basis:
            if rng.getrandbits(1):
                v ^= b
        words = expand_numeric(vector_to_initial_words(v), end + 1)
        if not v or not all_active(words, support):
            candidate = random_solution_with_all_active(basis, support, end, rng.randrange(1 << 30), attempts=2000)
            if candidate is None:
                continue
            v = candidate
        score = raw_objective(v, support, end, window_end)
        improved = True
        while improved:
            improved = False
            order = list(range(len(basis)))
            rng.shuffle(order)
            for idx in order:
                nv = v ^ basis[idx]
                if not nv:
                    continue
                nwords = expand_numeric(vector_to_initial_words(nv), end + 1)
                if not all_active(nwords, support):
                    continue
                ns = raw_objective(nv, support, end, window_end)
                if ns < score:
                    v, score = nv, ns
                    improved = True
        if best_score is None or score < best_score:
            best_v, best_score = v, score
    return best_v, best_score


def ch(x: int, y: int, z: int) -> int:
    return (x & y) ^ ((x ^ 1) & z)


def maj(x: int, y: int, z: int) -> int:
    return (x & y) ^ (x & z) ^ (y & z)


def differential_counts(fn: Callable[[int, int, int], int]) -> dict[str, dict[str, int | None]]:
    table: dict[str, dict[str, int | None]] = {}
    for d in range(8):
        de, df, dg = (d >> 2) & 1, (d >> 1) & 1, d & 1
        for dout in (0, 1):
            count = 0
            for base in range(8):
                e, f, g = (base >> 2) & 1, (base >> 1) & 1, base & 1
                if (fn(e, f, g) ^ fn(e ^ de, f ^ df, g ^ dg)) == dout:
                    count += 1
            cost = None if count == 0 else (0 if count == 8 else 1 if count == 4 else -1)
            table[f"{de}{df}{dg}->{dout}"] = {"count": count, "cost_bits": cost}
    return table


@dataclass
class PatternResult:
    name: str
    support: list[int]
    end: int
    rank: int
    nullity: int
    all_active_solution_found: bool
    sample_active_words_hex: dict[str, str] | None
    raw_window_end: int | None = None
    raw_total_hw: int | None = None
    raw_support_hw: int | None = None
    raw_tail_hw: int | None = None


def analyze_pattern(name: str, support_values: list[int], end: int, symbolic: list[list[int]], optimize: bool, seed: int, window_end: int) -> PatternResult:
    support = set(support_values)
    rows = constraints_for_support(symbolic, support, end)
    rr, pivots = rref(rows)
    basis = nullspace_basis(rr, pivots)
    sample = random_solution_with_all_active(basis, support, end, seed)
    best_score = None
    if optimize and sample is not None:
        best, best_score = hill_climb(basis, support, end, window_end, seed)
        if best is not None:
            sample = best
    active_hex = None
    if sample is not None:
        words = expand_numeric(vector_to_initial_words(sample), max(end, window_end) + 1)
        active_hex = {f"W{i}": f"0x{words[i]:08x}" for i in sorted(support)}
    return PatternResult(
        name=name,
        support=sorted(support),
        end=end,
        rank=len(pivots),
        nullity=N_VARS - len(pivots),
        all_active_solution_found=sample is not None,
        sample_active_words_hex=active_hex,
        raw_window_end=window_end if best_score is not None else None,
        raw_total_hw=best_score[0] if best_score else None,
        raw_support_hw=best_score[1] if best_score else None,
        raw_tail_hw=best_score[2] if best_score else None,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--window-end", type=int, default=35)
    parser.add_argument("--optimize", action="store_true", help="Run a small raw-Hamming-weight hill-climb")
    parser.add_argument("--json-out", default="/data/sha256_k1_results.json")
    args = parser.parse_args()

    patterns = [
        ("Mendel28", [8, 9, 13, 16, 18], 18),
        ("Mendel31", [5, 6, 7, 8, 9, 16, 18], 18),
        ("Zhang37", [6, 7, 9, 14, 22, 23], 23),
        ("Zhang36", [5, 7, 8, 13, 21, 22], 22),
        ("K1", [8, 9, 11, 16, 24, 25], 25),
        ("K2", [8, 10, 11, 16, 24, 25], 25),
    ]
    symbolic = build_symbolic_schedule(max(args.window_end + 1, 36))
    results = [
        analyze_pattern(name, support, end, symbolic, args.optimize, args.seed + idx, args.window_end)
        for idx, (name, support, end) in enumerate(patterns)
    ]

    # Known expected nullities from the research notes.
    expected = {"Mendel28": 96, "Mendel31": 160, "Zhang37": 64, "Zhang36": 96, "K1": 32, "K2": 0}
    checks = {r.name: (r.nullity == expected[r.name]) for r in results}

    # Explicit rotation sanity check mentioned in the notes.
    msb = 0x80000000
    msb_check = {
        "s0_of_msb_hex": f"0x{s0_num(msb):08x}",
        "s0_set_bits": [i for i in range(32) if (s0_num(msb) >> i) & 1],
        "s1_of_msb_hex": f"0x{s1_num(msb):08x}",
        "s1_set_bits": [i for i in range(32) if (s1_num(msb) >> i) & 1],
    }

    output = {
        "warning": "Necessary-condition XOR-linear pre-screen only; not a complete SHA-256 collision model.",
        "patterns": [asdict(r) for r in results],
        "expected_nullity_checks": checks,
        "msb_small_sigma_check": msb_check,
        "Ch_one_bit_DDT": differential_counts(ch),
        "Maj_one_bit_DDT": differential_counts(maj),
    }
    with open(args.json_out, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
