# تجربة K1 دون SAT/SMT

## المكونات

- `sha256_k1_test.py`: بناء جدول الرسالة الخطي فوق GF(2) واستخراج nullspace.
- `sha256_k1_carry_mitm.py`: Carry-DP دقيق محليًا، واختبارات شاملة صغيرة، وMITM، وBranch-and-Bound.
- `sha256_k1_carry_mitm_results.json`: النتيجة الأساسية الكاملة.
- `k1_seed17.json` و`k1_seed29.json`: تشغيلان إضافيان لقياس الثبات.

## التشغيل

```bash
python3 sha256_k1_carry_mitm.py \
  --seed 20260914 \
  --window-end 35 \
  --projections 10 \
  --projection-bits 14 \
  --bucket-cap 4 \
  --keep 60 \
  --bnb-node-limit 2000000 \
  --bnb-seconds 45
```

## اختبارات صحة Carry-DP

نجحت الاختبارات التالية:

1. جميع حالات فرق جمع معاملين من 4 بت: 4096 حالة.
2. 80 حالة عشوائية لجمع ثلاثة معاملات من 4 بت.
3. 80 حالة عشوائية من 6 بت مع معامل ثابت.

في كل حالة تطابق Dynamic Programming مع العد الشامل تمامًا.

## النتيجة الأساسية

- رتبة قيود K1: 480.
- بُعد nullspace: 32.
- عدد عناصر كل نصف MITM: 65536.
- عدد الأزواج المقيمة: 1,605,632.
- عدد المرشحين النشطين المختلفين: 1,603,923.
- أفضل وزن خام: 44 = وزن الدعم 18 + وزن tail 26.
- جميع جمعات جدول الرسالة من W16 إلى W35 ممكنة محليًا وفق Carry-DP.
- مجموع التكلفة المحلية التشخيصي: 65 بت.

الكلمات النشطة لأفضل مرشح:

```text
W8  = 0x00000002
W9  = 0x04008000
W11 = 0x500102a0
W16 = 0x04008000
W24 = 0x20881002
W25 = 0x04008000
```

## حدود النتيجة

- MITM إسقاطي heuristic ولا يثبت الحل الأمثل.
- Branch-and-Bound توقف عند حد مليوني عقدة؛ لذلك `complete=false` ولا يثبت أن 44 هو الحد الأدنى.
- Carry-DP دقيق لكل عملية جمع منفردة، لكن جمع تكاليف W16..W35 ليس احتمالًا عالميًا بسبب مشاركة المتغيرات بين العمليات المتتالية.
- عدم وجود خطوة محلية مستحيلة شرط ضروري فقط، وليس إثباتًا لوجود زوج رسائل متسق عالميًا.
- لا يوجد ادعاء بإيجاد تصادم SHA-256.

## مراجع بحثية

- Lipmaa & Moriai, Efficient Algorithms for Computing Differential Properties of Addition: https://kodu.ut.ee/~lipmaa/papers/lm01/dpa.pdf
- Qin & Wu, Non-independence of consecutive modular additions: https://arxiv.org/abs/2203.09741
- Zhang et al., Collision Attacks on SHA-256 up to 37 Steps: https://eprint.iacr.org/2026/232
- Programmatic SAT study (للمقارنة المنهجية فقط): https://arxiv.org/abs/2406.20072
- Higher-Order Differential Attack on Reduced SHA-256: https://eprint.iacr.org/2011/037.pdf
