#!/usr/bin/env python3
"""Heuristic search for a real modular SHA-256 message-schedule pair for K1. No SAT/SMT."""
import argparse,json,math,random,time
from sha256_k1_test import MASK32,s0_num,s1_num,vector_to_initial_words,expand_numeric

def sched(x,n):
 w=[v&MASK32 for v in x]
 for i in range(16,n): w.append((s1_num(w[i-2])+w[i-7]+s0_num(w[i-15])+w[i-16])&MASK32)
 return w

def ev(base,target,end,protect=15):
 a=sched(base,end+1); b=sched([base[i]^target[i] for i in range(16)],end+1)
 mm=[(a[i]^b[i]^target[i]).bit_count() for i in range(16,end+1)]
 prefix=0
 for m in mm:
  if m: break
  prefix+=1
 weighted=sum(m*(24 if i+16<=protect else 1) for i,m in enumerate(mm))
 return weighted,sum(mm),prefix,mm,a,b

def improve(start,target,end,protect,rng,iterations,restarts,deadline):
 best=(list(start),ev(start,target,end,protect))
 for r in range(restarts):
  if time.time()>deadline: break
  cur=list(best[0]) if r==0 else [rng.getrandbits(32) for _ in range(16)]
  ce=ev(cur,target,end,protect); local=(list(cur),ce)
  for it in range(iterations):
   if time.time()>deadline: break
   wi=rng.randrange(16); old=cur[wi]
   if rng.random()<.88: cur[wi]^=1<<rng.randrange(32)
   else: cur[wi]^=(1<<rng.randrange(32))^(1<<rng.randrange(32))
   ne=ev(cur,target,end,protect); delta=ne[0]-ce[0]; temp=max(.15,14*(1-it/max(1,iterations)))
   if delta<=0 or rng.random()<math.exp(-min(delta,700)/temp):
    ce=ne
    if (ce[0],ce[1],-ce[2])<(local[1][0],local[1][1],-local[1][2]): local=(list(cur),ce)
   else: cur[wi]=old
   if ce[1]==0: return list(cur),ce
  if (local[1][0],local[1][1],-local[1][2])<(best[1][0],best[1][1],-best[1][2]): best=local
 return best

def main():
 p=argparse.ArgumentParser(); p.add_argument('--target-json',default='/data/sha256_k1_carry_mitm_results.json'); p.add_argument('--seed',type=int,default=909); p.add_argument('--seconds',type=float,default=120); p.add_argument('--iterations',type=int,default=90000); p.add_argument('--restarts',type=int,default=8); p.add_argument('--out',default='/data/k1_progressive_actual_results.json'); a=p.parse_args()
 d=json.load(open(a.target_json)); v=int(d['best_raw_candidate']['initial_vector']); target=expand_numeric(vector_to_initial_words(v),36)
 rng=random.Random(a.seed); deadline=time.time()+a.seconds; base=[rng.getrandbits(32) for _ in range(16)]; stages=[]; protect=15; last_exact=None
 for end in (25,27,29,31,33,35):
  if time.time()>deadline: break
  candidate,res=improve(base,target,end,protect,rng,a.iterations,a.restarts,deadline)
  item={'end':end,'exact':res[1]==0,'mismatch_bits':res[1],'prefix':res[2],'per_word':{f'W{i}':m for i,m in enumerate(res[3],16)},'base_words_hex':[f'0x{x:08x}' for x in candidate]}
  stages.append(item)
  if res[1]==0:
   base=candidate; protect=end; last_exact=item
  else: break
 final=last_exact or stages[-1]
 out={'method':'progressive simulated annealing over actual modular schedules; no SAT/SMT','parameters':vars(a),'stages':stages,'last_exact_stage':final,'elapsed_seconds':a.seconds-max(0,deadline-time.time()),'warning':'Failure is heuristic evidence, not impossibility proof; schedule success is not a state collision.'}
 json.dump(out,open(a.out,'w'),indent=2); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
