#!/usr/bin/env python3
"""Independent verifier for the best exact modular K1 schedule pair and reduced SHA-256 state."""
import argparse,json
from sha256_k1_test import MASK32,rotr32,s0_num,s1_num,vector_to_initial_words,expand_numeric
from k1_progressive_actual import sched
K=[
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
def B0(x): return rotr32(x,2)^rotr32(x,13)^rotr32(x,22)
def B1(x): return rotr32(x,6)^rotr32(x,11)^rotr32(x,25)
def Ch(x,y,z): return (x&y)^((~x)&z)
def Maj(x,y,z): return (x&y)^(x&z)^(y&z)
def trace(words,rounds):
 a,b,c,d,e,f,g,h=IV; out=[]
 for i in range(rounds):
  t1=(h+B1(e)+Ch(e,f,g)+K[i]+words[i])&MASK32
  t2=(B0(a)+Maj(a,b,c))&MASK32
  a,b,c,d,e,f,g,h=(t1+t2)&MASK32,a,b,c,(d+t1)&MASK32,e,f,g
  out.append((a,b,c,d,e,f,g,h))
 return out
def main():
 p=argparse.ArgumentParser(); p.add_argument('--progressive',default='/data/k1_progressive_actual_results.json'); p.add_argument('--target',default='/data/sha256_k1_carry_mitm_results.json'); p.add_argument('--out',default='/data/verify_k1_pair_results.json'); a=p.parse_args()
 pd=json.load(open(a.progressive)); stage=pd['last_exact_stage']; base=[int(x,16) for x in stage['base_words_hex']]
 td=json.load(open(a.target)); target=expand_numeric(vector_to_initial_words(int(td['best_raw_candidate']['initial_vector'])),36)
 pair=[base[i]^target[i] for i in range(16)]; w=sched(base,36); wp=sched(pair,36)
 schedule=[]
 for i in range(36):
  actual=w[i]^wp[i]; schedule.append({'step':i,'target':f'0x{target[i]:08x}','actual':f'0x{actual:08x}','match':actual==target[i],'mismatch_bits':(actual^target[i]).bit_count()})
 tr=trace(w,36); trp=trace(wp,36); states=[]
 for i,(x,y) in enumerate(zip(tr,trp)):
  dif=[u^v for u,v in zip(x,y)]; states.append({'step':i,'difference_hex':[f'0x{z:08x}' for z in dif],'hw':sum(z.bit_count() for z in dif),'zero':all(z==0 for z in dif)})
 out={'exact_schedule_through':stage['end'],'all_schedule_matches_through_exact_stage':all(x['match'] for x in schedule[:stage['end']+1]),'base_words_hex':[f'0x{x:08x}' for x in base],'pair_words_hex':[f'0x{x:08x}' for x in pair],'schedule':schedule,'state_trace':states,'state_zero_steps':[x['step'] for x in states if x['zero']],'final_state_hw_round36':states[-1]['hw'],'collision_round36':states[-1]['zero']}
 json.dump(out,open(a.out,'w'),indent=2); print(json.dumps({'exact_schedule_through':out['exact_schedule_through'],'verified':out['all_schedule_matches_through_exact_stage'],'state_zero_steps':out['state_zero_steps'],'final_state_hw_round36':out['final_state_hw_round36'],'collision_round36':out['collision_round36']},indent=2))
if __name__=='__main__': main()
