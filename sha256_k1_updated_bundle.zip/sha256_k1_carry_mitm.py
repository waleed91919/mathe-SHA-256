#!/usr/bin/env python3
"""
K1 research prototype without SAT/SMT/bit-vectors.

Components
----------
1. Exact carry dynamic programming for XOR differentials of modular addition.
2. Exhaustive small-word tests of the DP (including a fixed constant operand).
3. GF(2) nullspace construction for the K1 linearized message schedule.
4. Projection-based meet-in-the-middle search over the 32-dimensional K1 space.
5. Admissible branch-and-bound for raw support+tail Hamming weight.
6. Exact *local* carry-DP feasibility/cost for message-schedule additions.

Important limitations
---------------------
- The K1 nullspace comes from the XOR-linearized message schedule.
- Local addition probabilities in consecutive schedule equations are dependent;
  summing their costs is a diagnostic independence score, not a global proof.
- A zero local count is a rigorous local impossibility. A nonzero local count
  does not prove one globally consistent message pair exists.
- This program does not claim a SHA-256 collision.
"""

from __future__ import annotations

import argparse
import heapq
import itertools
import json
import math
import random
import time
from dataclasses import dataclass, asdict
from typing import Iterable, Optional

from sha256_k1_test import (
    MASK32,
    build_symbolic_schedule,
    constraints_for_support,
    expand_numeric,
    nullspace_basis,
    rref,
    s0_num,
    s1_num,
    vector_to_initial_words,
)


def add_xor_dp(
    deltas: list[int],
    out_delta: int,
    n_bits: int,
    fixed_values: Optional[list[Optional[int]]] = None,
) -> tuple[int, int]:
    """Count assignments realizing an XOR differential through modular addition.

    Returns (count, denominator_exponent), where probability=count/2**exponent.
    Each operand is either uniformly free or fixed to a supplied word. The same
    fixed operand is used in both computations; therefore its delta must be 0.
    Final carry-out is discarded, as required by addition modulo 2**n_bits.
    """
    m = len(deltas)
    if m < 2:
        raise ValueError("at least two operands are required")
    mask = (1 << n_bits) - 1
    deltas = [d & mask for d in deltas]
    out_delta &= mask
    if fixed_values is None:
        fixed_values = [None] * m
    if len(fixed_values) != m:
        raise ValueError("fixed_values length mismatch")
    for d, value in zip(deltas, fixed_values):
        if value is not None and d != 0:
            return 0, sum(v is None for v in fixed_values) * n_bits

    free_indices = [j for j, value in enumerate(fixed_values) if value is None]
    exponent = len(free_indices) * n_bits
    states: dict[tuple[int, int], int] = {(0, 0): 1}

    for bit in range(n_bits):
        wanted = (out_delta >> bit) & 1
        nxt: dict[tuple[int, int], int] = {}
        for (carry, carry_p), ways in states.items():
            for free_bits in itertools.product((0, 1), repeat=len(free_indices)):
                bits = [0] * m
                free_pos = 0
                for j, fixed in enumerate(fixed_values):
                    if fixed is None:
                        bits[j] = free_bits[free_pos]
                        free_pos += 1
                    else:
                        bits[j] = (fixed >> bit) & 1
                bits_p = [b ^ ((deltas[j] >> bit) & 1) for j, b in enumerate(bits)]
                total = sum(bits) + carry
                total_p = sum(bits_p) + carry_p
                if ((total & 1) ^ (total_p & 1)) != wanted:
                    continue
                key = (total >> 1, total_p >> 1)
                nxt[key] = nxt.get(key, 0) + ways
        states = nxt
        if not states:
            return 0, exponent
    return sum(states.values()), exponent


def differential_cost(count: int, exponent: int) -> float:
    if count == 0:
        return math.inf
    return exponent - math.log2(count)


def brute_add_count(
    deltas: list[int],
    out_delta: int,
    n_bits: int,
    fixed_values: Optional[list[Optional[int]]] = None,
) -> tuple[int, int]:
    """Small-word exhaustive oracle used only to test add_xor_dp."""
    m = len(deltas)
    mask = (1 << n_bits) - 1
    if fixed_values is None:
        fixed_values = [None] * m
    free = [i for i, v in enumerate(fixed_values) if v is None]
    count = 0
    for values in itertools.product(range(1 << n_bits), repeat=len(free)):
        ops = [0] * m
        k = 0
        for i, fixed in enumerate(fixed_values):
            if fixed is None:
                ops[i] = values[k]
                k += 1
            else:
                ops[i] = fixed & mask
        ops_p = [ops[i] ^ (deltas[i] & mask) for i in range(m)]
        z = sum(ops) & mask
        zp = sum(ops_p) & mask
        if (z ^ zp) == (out_delta & mask):
            count += 1
    return count, len(free) * n_bits


def self_test(seed: int = 1) -> dict:
    rng = random.Random(seed)
    cases = []
    # Exact all-difference coverage for two 4-bit operands: 16^3=4096 cases.
    for a in range(16):
        for b in range(16):
            for g in range(16):
                dp = add_xor_dp([a, b], g, 4)
                brute = brute_add_count([a, b], g, 4)
                if dp != brute:
                    raise AssertionError((a, b, g, dp, brute))
    cases.append({"name": "two_free_operands_4bit_all_4096", "passed": True})

    # Random 3-operand and fixed-constant checks at 4/6 bits.
    for n_bits, operands, fixed, trials in [
        (4, 3, [None, None, None], 80),
        (6, 2, [None, rng.randrange(64)], 80),
    ]:
        for _ in range(trials):
            ds = [rng.randrange(1 << n_bits) if fixed[i] is None else 0 for i in range(operands)]
            out = rng.randrange(1 << n_bits)
            dp = add_xor_dp(ds, out, n_bits, fixed)
            brute = brute_add_count(ds, out, n_bits, fixed)
            if dp != brute:
                raise AssertionError((n_bits, ds, out, fixed, dp, brute))
        cases.append({"name": f"random_{operands}operand_{n_bits}bit_{trials}", "passed": True})
    return {"passed": True, "cases": cases}


def concat_words(words: list[int]) -> int:
    sig = 0
    for i, w in enumerate(words):
        sig |= (w & MASK32) << (32 * i)
    return sig


def words_from_signature(sig: int, n_words: int) -> list[int]:
    return [(sig >> (32 * i)) & MASK32 for i in range(n_words)]


def objective_mask(support: set[int], end: int, window_end: int) -> int:
    mask = 0
    for i in sorted(support | set(range(end + 1, window_end + 1))):
        mask |= MASK32 << (32 * i)
    return mask


def active_ok(sig: int, support: set[int]) -> bool:
    return all(((sig >> (32 * i)) & MASK32) != 0 for i in support)


def enumerate_half(effects: list[int], vectors: list[int]) -> list[tuple[int, int, int]]:
    """Return (expanded_signature, initial_vector, coefficient_mask)."""
    n = len(effects)
    out: list[tuple[int, int, int]] = []
    sig = vec = 0
    previous_gray = 0
    out.append((0, 0, 0))
    for k in range(1, 1 << n):
        gray = k ^ (k >> 1)
        changed = gray ^ previous_gray
        bit = changed.bit_length() - 1
        sig ^= effects[bit]
        vec ^= vectors[bit]
        out.append((sig, vec, gray))
        previous_gray = gray
    return out


def compress_projection(value: int, positions: list[int]) -> int:
    key = 0
    for j, p in enumerate(positions):
        key |= ((value >> p) & 1) << j
    return key


@dataclass(order=True)
class Candidate:
    raw_weight: int
    initial_vector: int
    coefficient_mask: int
    source: str


def mitm_search(
    basis: list[int],
    effects: list[int],
    obj_mask: int,
    support: set[int],
    seed: int,
    projections: int,
    projection_bits: int,
    bucket_cap: int,
    keep: int,
) -> tuple[list[Candidate], dict]:
    if len(basis) != 32:
        raise ValueError("this MITM implementation expects K1 nullity 32")
    rng = random.Random(seed)
    left = enumerate_half(effects[:16], basis[:16])
    right = enumerate_half(effects[16:], basis[16:])
    positions = [p for p in range(obj_mask.bit_length()) if (obj_mask >> p) & 1]
    best: dict[int, Candidate] = {}
    pair_evaluations = 0

    # Include simple same-key random projections. Equal projected halves cancel.
    for _ in range(projections):
        proj = rng.sample(positions, min(projection_bits, len(positions)))
        buckets: dict[int, list[tuple[int, int, int]]] = {}
        # Keep low individual masked weight entries per bucket.
        for entry in right:
            key = compress_projection(entry[0], proj)
            bucket = buckets.setdefault(key, [])
            item = ((entry[0] & obj_mask).bit_count(), entry)
            if len(bucket) < bucket_cap:
                bucket.append(entry)
            else:
                worst_i = max(range(len(bucket)), key=lambda i: (bucket[i][0] & obj_mask).bit_count())
                if item[0] < (bucket[worst_i][0] & obj_mask).bit_count():
                    bucket[worst_i] = entry
        for lsig, lvec, lcoeff in left:
            key = compress_projection(lsig, proj)
            for rsig, rvec, rcoeff in buckets.get(key, ()):
                pair_evaluations += 1
                sig = lsig ^ rsig
                if not active_ok(sig, support):
                    continue
                vec = lvec ^ rvec
                coeff = lcoeff | (rcoeff << 16)
                cand = Candidate((sig & obj_mask).bit_count(), vec, coeff, "mitm")
                old = best.get(vec)
                if old is None or cand.raw_weight < old.raw_weight:
                    best[vec] = cand

    candidates = heapq.nsmallest(keep, best.values())
    stats = {
        "left_entries": len(left),
        "right_entries": len(right),
        "projections": projections,
        "projection_bits": projection_bits,
        "bucket_cap": bucket_cap,
        "pair_evaluations": pair_evaluations,
        "unique_active_candidates": len(best),
    }
    return candidates, stats


def branch_and_bound(
    basis: list[int],
    effects: list[int],
    obj_mask: int,
    support: set[int],
    incumbent: Candidate,
    node_limit: int,
    time_limit: float,
) -> tuple[Candidate, dict]:
    # High-impact variables first generally strengthen the lower bound earlier.
    order = sorted(range(len(basis)), key=lambda i: (effects[i] & obj_mask).bit_count(), reverse=True)
    b = [basis[i] for i in order]
    e = [effects[i] for i in order]
    preferred = [((incumbent.coefficient_mask >> i) & 1) for i in order]
    n = len(b)

    remaining_union = [0] * (n + 1)
    remaining_support_union = [0] * (n + 1)
    support_mask = 0
    for wi in support:
        support_mask |= MASK32 << (32 * wi)
    for d in range(n - 1, -1, -1):
        remaining_union[d] = remaining_union[d + 1] | (e[d] & obj_mask)
        remaining_support_union[d] = remaining_support_union[d + 1] | (e[d] & support_mask)

    best = Candidate(incumbent.raw_weight, incumbent.initial_vector, incumbent.coefficient_mask, "bnb_incumbent")
    nodes = 0
    pruned_bound = 0
    pruned_activity = 0
    start = time.time()
    complete = True

    def dfs(depth: int, sig: int, vec: int, coeff_original: int) -> None:
        nonlocal best, nodes, pruned_bound, pruned_activity, complete
        if nodes >= node_limit or time.time() - start >= time_limit:
            complete = False
            return
        nodes += 1
        immutable_ones = (sig & obj_mask) & ~remaining_union[depth]
        lower = immutable_ones.bit_count()
        if lower >= best.raw_weight:
            pruned_bound += 1
            return
        # If an active word is currently zero and no remaining effect can touch it, prune.
        for wi in support:
            wm = MASK32 << (32 * wi)
            if (sig & wm) == 0 and (remaining_support_union[depth] & wm) == 0:
                pruned_activity += 1
                return
        if depth == n:
            if vec and active_ok(sig, support):
                score = (sig & obj_mask).bit_count()
                if score < best.raw_weight:
                    # Convert reordered decisions are already recorded in original indexes.
                    best = Candidate(score, vec, coeff_original, "bnb")
            return

        original_index = order[depth]
        choices = (preferred[depth], 1 - preferred[depth])
        for bit in choices:
            if not complete:
                return
            if bit:
                dfs(depth + 1, sig ^ e[depth], vec ^ b[depth], coeff_original | (1 << original_index))
            else:
                dfs(depth + 1, sig, vec, coeff_original & ~(1 << original_index))

    dfs(0, 0, 0, 0)
    return best, {
        "nodes": nodes,
        "node_limit": node_limit,
        "time_seconds": time.time() - start,
        "time_limit_seconds": time_limit,
        "complete": complete,
        "pruned_by_lower_bound": pruned_bound,
        "pruned_by_activity": pruned_activity,
        "proves_raw_optimum": complete,
    }


def local_schedule_carry_score(words: list[int], first: int = 16, last: int = 35) -> dict:
    steps = []
    total = 0.0
    impossible = []
    for i in range(first, last + 1):
        deltas = [s1_num(words[i - 2]), words[i - 7], s0_num(words[i - 15]), words[i - 16]]
        count, exponent = add_xor_dp(deltas, words[i], 32)
        cost = differential_cost(count, exponent)
        if math.isinf(cost):
            impossible.append(i)
            rendered_cost = None
        else:
            total += cost
            rendered_cost = cost
        steps.append({
            "step": i,
            "count_nonzero": count != 0,
            "local_cost_bits": rendered_cost,
        })
    return {
        "range": [first, last],
        "all_locally_feasible": not impossible,
        "locally_impossible_steps": impossible,
        "sum_local_cost_bits_independence_diagnostic": None if impossible else total,
        "warning": "The sum is not a global probability because schedule additions share variables.",
        "steps": steps,
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=20260914)
    p.add_argument("--window-end", type=int, default=35)
    p.add_argument("--projections", type=int, default=10)
    p.add_argument("--projection-bits", type=int, default=14)
    p.add_argument("--bucket-cap", type=int, default=4)
    p.add_argument("--keep", type=int, default=60)
    p.add_argument("--bnb-node-limit", type=int, default=2_000_000)
    p.add_argument("--bnb-seconds", type=float, default=45.0)
    p.add_argument("--json-out", default="/data/sha256_k1_carry_mitm_results.json")
    args = p.parse_args()

    started = time.time()
    tests = self_test(args.seed)

    support = {8, 9, 11, 16, 24, 25}
    end = 25
    symbolic = build_symbolic_schedule(args.window_end + 1)
    rr, pivots = rref(constraints_for_support(symbolic, support, end))
    basis = nullspace_basis(rr, pivots)
    if len(basis) != 32:
        raise AssertionError(f"K1 nullity changed: {len(basis)}")

    effects = [concat_words(expand_numeric(vector_to_initial_words(v), args.window_end + 1)) for v in basis]
    obj_mask = objective_mask(support, end, args.window_end)

    candidates, mitm_stats = mitm_search(
        basis, effects, obj_mask, support, args.seed,
        args.projections, args.projection_bits, args.bucket_cap, args.keep,
    )
    if not candidates:
        raise RuntimeError("MITM found no all-active candidate")

    incumbent = candidates[0]
    best, bnb_stats = branch_and_bound(
        basis, effects, obj_mask, support, incumbent,
        args.bnb_node_limit, args.bnb_seconds,
    )

    merged: dict[int, Candidate] = {c.initial_vector: c for c in candidates}
    merged[best.initial_vector] = best
    ranked = sorted(merged.values())[: min(20, len(merged))]

    evaluated = []
    for c in ranked:
        words = expand_numeric(vector_to_initial_words(c.initial_vector), args.window_end + 1)
        carry = local_schedule_carry_score(words, 16, args.window_end)
        evaluated.append({
            "raw_weight": c.raw_weight,
            "source": c.source,
            "coefficient_mask_hex": f"0x{c.coefficient_mask:08x}",
            "active_words_hex": {f"W{i}": f"0x{words[i]:08x}" for i in sorted(support)},
            "tail_weight": sum(words[i].bit_count() for i in range(end + 1, args.window_end + 1)),
            "support_weight": sum(words[i].bit_count() for i in support),
            "carry_dp": carry,
        })

    # Rank locally feasible candidates by diagnostic carry sum, then raw weight.
    evaluated.sort(key=lambda x: (
        not x["carry_dp"]["all_locally_feasible"],
        x["carry_dp"]["sum_local_cost_bits_independence_diagnostic"]
        if x["carry_dp"]["sum_local_cost_bits_independence_diagnostic"] is not None else math.inf,
        x["raw_weight"],
    ))

    output = {
        "scope": "K1 32-dimensional XOR-linear nullspace; no SAT/SMT/bit-vector solver",
        "theoretical_status": {
            "carry_dp": "exact for each modeled modular addition",
            "mitm": "heuristic projection search; not exhaustive nearest-neighbor proof",
            "branch_and_bound": "exact raw-weight proof only if complete=true",
            "local_schedule_cost_sum": "diagnostic only due dependence between consecutive additions",
            "collision_claim": False,
        },
        "parameters": vars(args),
        "self_tests": tests,
        "k1": {
            "rank": len(pivots),
            "nullity": len(basis),
            "support": sorted(support),
            "end": end,
            "objective_words": sorted(support | set(range(end + 1, args.window_end + 1))),
        },
        "mitm_stats": mitm_stats,
        "branch_and_bound_stats": bnb_stats,
        "best_raw_candidate": asdict(best),
        "top_carry_evaluated_candidates": evaluated,
        "total_runtime_seconds": time.time() - started,
    }
    with open(args.json_out, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
